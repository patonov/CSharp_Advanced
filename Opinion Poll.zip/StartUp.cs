﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            List<Person> people = new List<Person>();

            for (int i = 0; i < n; i++)
            {
                string[] personData = Console.ReadLine().Split();
                string personName = personData[0];
                int personAge = int.Parse(personData[1]);

                Person currentPerson = new Person(personName, personAge);
                people.Add(currentPerson);

            }

            List<Person> filtered = people.Where(x => x.Age > 30).OrderBy(x => x.Name).ToList();

            foreach (Person somebody in filtered)
            {
                Console.WriteLine($"{somebody.Name} - {somebody.Age}");
            }


        }
    }
}


