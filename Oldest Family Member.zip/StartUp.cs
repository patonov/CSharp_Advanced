﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            Family family = new Family();

            for (int i = 0; i < n; i++)
            {
                var personInfo = Console.ReadLine().Split().ToArray();
                string name = personInfo[0];
                int ages = int.Parse(personInfo[1]);
                Person person = new Person(name, ages);
                family.AddMember(person);
            }


            var man = family.GetOldestMember();
            Console.WriteLine("{0} {1}", man.Name, man.Age);



        }
    }
}


