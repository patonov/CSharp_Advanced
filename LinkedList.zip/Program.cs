﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinkedList
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Node head = new Node(1);
            Node headOne = new Node(2);
            Node headTwo = new Node(3);
            Node headThree = new Node(4);

            head.Next = headOne;
            headOne.Next = headTwo;
            headTwo.Next = headThree;

            Node currentNode = head;

            while (currentNode != null)
            {
                Console.WriteLine(currentNode.Value);
                currentNode = currentNode.Next;
            }
                         
        }
    }
}
