﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace Even_Lines
{
    class Program
    {
        static void Main(string[] args)
        {
            var reader = new StreamReader("d:/documents/visual studio 2015/Projects/text.txt");

            using (reader)
            {
                int counter = 0;
                string line = reader.ReadLine();
                using (var writer = new StreamWriter("d:/documents/visual studio 2015/Projects/Output.txt"))
                {
                    while (line != null)
                    {
                        if (counter % 2 == 0)
                        {
                            writer.WriteLine(line);
                        }
                        counter++;
                        line = reader.ReadLine();
                    }
                }
            }
        }
    }
}
