﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Reverse_Even_Line
{
    class Program
    {
        static void Main(string[] args)
        {
            var reader = new StreamReader("d:/documents/visual studio 2015/Projects/text.txt");

            using (reader)
            {
                int counter = 0;
                string line = reader.ReadLine();

                while (line != null)
                {
                    char[] charToReplace = { '-', ',', '.', '!', '?' };

                    if (counter % 2 == 0)
                    {
                        for (int i = 0; i < charToReplace.Length; i++)
                        {
                            if (line.Contains(charToReplace[i]))
                            {
                                line = line.Replace(charToReplace[i], '@');
                                string[] reverseLine = line.Split();
                                var lineStack = new Stack<string>(reverseLine);
                                line = string.Join(" ", lineStack);
                            }
                        }
                        Console.WriteLine(line);
                    }
                    counter++;
                    line = reader.ReadLine();
                }
            }
        }
    }
}
