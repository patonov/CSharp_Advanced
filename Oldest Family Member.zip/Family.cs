﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace DefiningClasses
{
    public class Family
    {
        public Family()
        {
            this.FamilyPersons = new List<Person>();
        }

        public List<Person> FamilyPersons { get; set; }

        public void AddMember(Person member)
        {
            FamilyPersons.Add(member);
        }


        public Person GetOldestMember()
        {
            return FamilyPersons.OrderByDescending(x => x.Age).FirstOrDefault();

        }

    }
}

