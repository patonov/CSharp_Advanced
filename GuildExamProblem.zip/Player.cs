﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace Guild
{
    public class Player
    {
        private string name;
        private string @class;
        private const string rank = "Trial";
        private string description = "n/a";

        public Player(string name, string @class)
        {
            this.Name = name;
            this.Class = @class;
        }

        public string Name
        {
            get => this.name;
            private set
            {
                this.name = value;
            }
        }

        public string Class
        {
            get => this.@class;
            private set
            {
                this.@class = value;
            }
        }

        public string Rank { get; set; }
        

        public string Description { get; set; }
        

        public override string ToString()
        {
            return $"Player {this.Name}: {this.Class}" + Environment.NewLine +
                    $"Rank: {this.Rank}" + Environment.NewLine + 
                   $"Description: {this.Description}";

        }


    }
}
