﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListyIteratorProblem
{
    public class Program
    {
        public static void Main(string[] args)
        {
            List<string> input = Console.ReadLine().Split().Skip(1).ToList();

            ListyIterator<string> list = new ListyIterator<string>(input);

            string command = Console.ReadLine();

            while (command != "END")
            {
                switch (command)
                {

                    case "Move": Console.WriteLine(list.Move());
                        break;

                    case "HasNext" : Console.WriteLine(list.HasNext());
                        break;

                    case "Print": list.Print();
                        break;
                }
                command = Console.ReadLine();

            }


        }
    }
}
