﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace ClassroomProject
{
    public class Classroom
    {
        private readonly List<Student> students;
        private int capacity;

        public Classroom(int capacity)
        {
            this.Capacity = capacity;
            this.students = new List<Student>();
        }

        public int Capacity
        {
            get => this.capacity;
            set
            {
                this.capacity = value;
            }
        }

        public int Count => this.students.Count;

        public void RegisterStudent(Student student)
        {
            if (this.Count < this.Capacity)
            {
                Console.WriteLine("No seats in the classroom");
            }

            this.students.Add(student);
            Console.WriteLine( $"Added student {student.FirstName} {student.LastName}");
        }

        public string DismissStudent(string firstName, string lastName)
        {
            foreach (Student student in this.students)
            {
                if (student.FirstName == firstName && student.LastName == lastName)
                {                    
                    this.students.Remove(student);
                    return $"Dismissed student {firstName} {lastName}";                    
                }
            }
           return "Student not found";
        }

        public string GetSubjectInfo(string subject)
        {
            List<Student> studentsInSubject = this.students.Where(st => st.Subject == subject).ToList();

            if (studentsInSubject.Count > 0)
            {
                StringBuilder sb = new StringBuilder();
                sb.Append($"Subject: {subject}");
                sb.Append(Environment.NewLine);
                sb.Append("Students:");
                sb.Append(Environment.NewLine);

                foreach (Student student in studentsInSubject)
                {
                    sb.Append($"{student.FirstName} {student.LastName}");
                    sb.Append(Environment.NewLine);
                }
                return sb.ToString();
            }

            return "No students enrolled for the subject";
        }

        public int GetStudentsCount()
        {
            return this.students.Count;
        }

        public Student GetStudent(string firstName, string lastName)
        {
            return (Student)this.students.Where(st => st.FirstName == firstName && st.LastName == lastName);
        }
    }
}
