﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DefiningClasses;

namespace DefiningClasses
{
    public class Family
    {

        public Family()
        {
        this.FamilyPersons = new List<Person>();
        }

        public List<Person> FamilyPersons { get; set; }

        public void AddMember(Person member)
        {
            FamilyPersons.Add(member);
        }

        
        public Person GetOldestMember()
        {
            Person oldestPerson = FamilyPersons.OrderByDescending(x => x.Age).FirstOrDefault();

            return oldestPerson;
        }     

    }
}
