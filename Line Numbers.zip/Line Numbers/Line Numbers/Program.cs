﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Line_Numbers
{
    class Program
    {
        static void Main(string[] args)
        {
            var reader = new StreamReader("d:/documents/visual studio 2015/Projects/text.txt");
            int letterCout = 0;
            int signCounter = 0;
            int whiteSpaceCounter = 0;

            using (reader)
            {
                int counter = 0;
                string line = reader.ReadLine();
                using (var writer = new StreamWriter("d:/documents/visual studio 2015/Projects/Output.txt"))
                {
                    while (line != null)
                    {
                        counter++;

                        string lineString = line.ToString();

                        for (int i = 0; i < lineString.Length; i++)
                        {
                            char ch = lineString[i];

                            if (char.IsLetterOrDigit(ch))
                            {
                                letterCout++; 
                            }
                            if (char.IsWhiteSpace(ch))
                            {
                                whiteSpaceCounter++;
                            }
                        }
                        signCounter = lineString.Length - letterCout - whiteSpaceCounter;

                        writer.WriteLine($"{counter} {line} ({letterCout})({signCounter})");

                        letterCout = 0;
                        signCounter = 0;
                        whiteSpaceCounter = 0;

                        line = reader.ReadLine();
                    }
                }
            }
        }
    }
}
