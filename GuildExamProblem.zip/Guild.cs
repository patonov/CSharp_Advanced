﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace Guild
{
    public class Guild
    {
        private string name;
        private int capacity;
        private List<Player> players; 

        public Guild(string name, int capacity)
        {
            this.Name = name;
            this.Capacity = capacity;
            this.players = new List<Player>();
        }

        public string Name
        {
            get => this.name;
            private set
            {
                this.name = value;
            }
        }

        public int Capacity
        {
            get => this.capacity;
            private set
            {
                this.capacity = value;
            }
        }

        public void AddPlayer(Player player)
        {
            if (this.Capacity > this.players.Count)
            {
                this.players.Add(player);
            }
        }

        public bool RemovePlayer(string name)
        {
            if (this.players.Any(x => x.Name == name))
            {
                Player p = this.players.Where(x => x.Name == name).FirstOrDefault();
                this.players.Remove(p); 
                return true;
            }
            return false;
        }

        public void PromotePlayer(string name)
        {
            if (this.players.Any(x => x.Name == name))
            {
                Player p = this.players.Where(x => x.Name == name).FirstOrDefault();
                p.Rank = "Member";
            }
        }

        public void DemotePlayer(string name)
        {
            if (this.players.Any(x => x.Name == name))
            {
                Player p = this.players.Where(x => x.Name == name).FirstOrDefault();
                p.Rank = "Trial";
            }
        }

        public Player[] KickPlayersByClass(string @class)
        {
            List<Player> tempPlayerList = new List<Player>(); 
            foreach (var player in this.players)
            {
                if (player.Class == @class)
                {
                    tempPlayerList.Add(player); 
                }
            }
            Player[] kickPlayersArray = tempPlayerList.ToArray();

            this.players = this.players.Where(x => x.Class != @class).ToList();

            return kickPlayersArray;
        }

        public int Count
        {
            get => this.players.Count;
        }

        public string Report()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"Players in the guild: {this.Name}");
            foreach (Player p in this.players)
            {
                sb.Append($"{p.Name}" + Environment.NewLine);
            }
            return sb.ToString();
        }
    }
}
